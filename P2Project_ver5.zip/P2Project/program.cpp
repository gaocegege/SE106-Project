#include "program.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;
Program::Program()
{
	ui = new Interface();
}

Program::~Program()
{
	free(ui);
}

void Program::work()
{
	char cmd;
	cout << "Please choose the mode: \n"
		<< "0. Test mode\n"
		<< "1. UI mode\n"
		<< endl;
	cin >> cmd;
	switch (cmd)
	{
	case '0':

		break;
	case '1':
		ui->beginTowork();
		break;
	default:
		break;
	}
}

void Program::testRegister()
{
	clock_t start, finish;
	double myTime;
	cout << "input the number of users you want to test\n";
	int x;
	cin >> x;
	start = clock();
	ui->load();
	srand((unsigned)time(0));
	for (int i = 0; i < x; i++)
	{
		ui->register_t(createUserMachine());
	}
	ui->quitDo_offline();
	finish = clock();
	myTime = (double)(finish - start) / CLOCKS_PER_SEC;
	myTime = myTime / 1000.0;
	cout << myTime;
}

char *Program::randomString(int maxLength)
{
	char *result = new char[maxLength];
	char c;
	int length = rand() % (maxLength - 1) + 1;//determine the length of ID
	for (int i = 0; i < length; i++)
	{
		c = rand() % (122 - 65) + 65;
		if (c > 90 && c < 97)
			c += 7;
		result[i] = c;
	}
	result[length] = '\0';
	return result;
}

Information Program::createUserMachine()
{
	Information result;
	char *free1 = randomString(LENGTHOFID);
	char *free2 = randomString(LENGTHOFPWD);
	char *free3 = randomString(LENGTHOFNAME);
	char *free4 = randomString(LENGTHOFBIR);
	strcpy(result.identification, free1);
	strcpy(result.password, free2);
	strcpy(result.name, free3);
	strcpy(result.birthday, free4);
	result.gender = rand() % 1;
	free(free1);
	free(free2);
	free(free3);
	free(free4);
	return result;
}