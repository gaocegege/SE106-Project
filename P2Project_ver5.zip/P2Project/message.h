#ifndef MESSAGE_H
#define MESSAGE_H

#include "base.h"

struct Message
{
	char message[LENGTHOFMESSAGE];
	long pointer;
	bool isFinished;
};

#endif