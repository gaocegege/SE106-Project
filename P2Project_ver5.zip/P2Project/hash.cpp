#include "hash.h"

int HashTable::myhash(RecordNode &x)//BKDRHash
{
	unsigned  int  seed = 131;  //  31 131 1313 13131 131313 etc..
	unsigned  int  hash = 0;
	for (int i = 0; i < LENGTHOFID; i++)
	{
		if (x.username[i] == '\0')
			break;
		hash = hash  *  seed + x.username[i];
	}
	return  (hash & 0x7FFFFFFF) % (H + 1);
}

int HashTable::myhash(char *x)
{
	unsigned  int  seed = 131;  //  31 131 1313 13131 131313 etc..
	unsigned  int  hash = 0;
	for (int i = 0; i < LENGTHOFID; i++)
	{
		if (x[i] == '\0')
			break;
		hash = hash  *  seed + x[i];
	}
	return  (hash & 0x7FFFFFFF) % (H + 1);
}

HashTable::HashTable(int size)
:currentSize(size)
{
}

//if contains,return it,else return Node whose pointer is -2
RecordNode HashTable::contains(char *x)
{
	int h = myhash(x);
	SaveForm buf;
	RecordNode buf_r;
	long buf_p;
	ifstream ifs(INDEXFILE, ios::in | ios::binary);
	ofstream ofs(INDEXFILE, ios_base::in | ios_base::out | ios::binary);
	ifs.seekg(h*sizeof(SaveForm));
	ifs.read((char *)&buf, sizeof(buf));
	if (buf.pointerToNext == -2)
	{
		buf_r.pointer = -2;
		return buf_r;
	}

	while (buf.pointerToNext != -1)
	{
		if (strcmp(buf.record.username, x) == 0)
			return buf.record;
		ifs.seekg(buf.pointerToNext);
		ifs.read((char *)&buf, sizeof(buf));
	}

	if (strcmp(buf.record.username, x) == 0)
		return buf.record;
	buf_r.pointer = -2;
	return buf_r;
}

void HashTable::makeEmpty()
{
	
}

bool HashTable::insert(RecordNode &x)
{
	int h = myhash(x);
	SaveForm buf;
	long buf_p;
	ifstream ifs(INDEXFILE, ios::in | ios::binary);
	ofstream ofs(INDEXFILE, ios_base::in | ios_base::out | ios::binary);

	ofs.seekp(0, ios::end);
	ifs.seekg(h*sizeof(buf));
	ifs.read((char *)&buf, sizeof(buf));

	if (buf.pointerToNext == -2)
	{
		ofs.seekp(h*sizeof(buf));
		buf.record = x;
		buf.pointerToNext = -1;
		ofs.write((char *)&buf, sizeof(buf));
		return true;
	}
	else if (buf.pointerToNext == -1)
	{
		buf.pointerToNext = ofs.tellp();
		ofs.seekp(h*sizeof(buf));
		ofs.write((char *)&buf, sizeof(buf));
		ofs.seekp(0, ios::end);//save the x
		buf.pointerToNext = -1;
		buf.record = x;
		ofs.write((char *)&buf, sizeof(buf));
		return true;
	}

	while (buf.pointerToNext != -1)
	{
		buf_p = buf.pointerToNext;
		ifs.seekg(buf.pointerToNext);
		ifs.read((char *)&buf, sizeof(buf));
	}
	buf.pointerToNext = ofs.tellp();//get the new node's position
	ofs.seekp(buf_p);
	ofs.write((char *)&buf, sizeof(buf));//update the node

	ofs.seekp(0, ios::end);//save the x
	buf.pointerToNext = -1;
	buf.record = x;
	ofs.write((char *)&buf, sizeof(buf));
	return true;
}

void HashTable::begin()//����һ������һ�������Ĵ洢��ȡ�����Գ���
{
	SaveForm buf;
	ifstream ifs(INDEXFILE, ios::in | ios::binary);
	if (ifs.peek() == EOF)
	{
		ofstream ofs(INDEXFILE, ios::out | ios::binary);
		for (int i = 0; i < currentSize; i++)
		{
			buf.pointerToNext = -2;
			ofs.write((char *)&buf, sizeof(buf));
		}
		return;
	}
}

void HashTable::dump()//bug
{
	//now there is no need to dump the data
	return;
}