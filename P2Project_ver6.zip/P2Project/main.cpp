#include "program.h"
#include <iostream>
using namespace std;

int main()
{
	Program *prog = new Program();
	prog->work();
	system("pause");
	return 0;
}
