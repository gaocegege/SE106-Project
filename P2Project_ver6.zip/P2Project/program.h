#ifndef PROGRAM_H
#define PROGRAM_H
#include "interface.h"
class Program
{
public:
	Program();
	~Program();
	void work();
private:
	Interface *ui;

	void testRegister();
	char *randomString(int maxLength);
	Information createUserMachine();
};

#endif