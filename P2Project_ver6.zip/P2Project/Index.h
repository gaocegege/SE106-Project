#include <string>
#include "base.h"
using namespace std;

struct RecordNode
{
	char username[LENGTHOFID];
	int pointer;
	bool operator==(const RecordNode& x)
	{
		return  this->username == x.username;
	}
};

struct SaveForm
{
	RecordNode record;
	long pointerToNext;
};

struct RecordNode_name
{
	char username[LENGTHOFNAME];
	int pointer;
	bool operator==(const RecordNode_name& x)
	{
		return  this->username == x.username;
	}
};

struct SaveForm_name
{
	RecordNode_name record;
	long pointerToNext;
};

struct RecordNode_bir
{
	char username[LENGTHOFBIR];
	int pointer;
	bool operator==(const RecordNode_bir& x)
	{
		return  this->username == x.username;
	}
};

struct SaveForm_bir
{
	RecordNode_bir record;
	long pointerToNext;
};