#ifndef BASE_H
#define BASE_H

#define LENGTHOFMESSAGE		141
#define LENGTHOFID			21
#define LENGTHOFPWD			31 //the length of the pwd is 8-32
#define LENGTHOFNAME		21
#define LENGTHOFBIR			11 //XXXX-XX-XX
#define LENGTHOFTELEPHONE	12
#define LENGTHOFADDRESS		20

#define INFOFILE	"info"//userInfo
#define INDEXFILE	"index"//index file
#define NAMEINDEXFILE "index_name"
#define BIRINDEXFILE "index_bir"
#define MESSAGEFILE "meg"//message
#define LIKEFILE	"like"//relationship
#define STATEFILE	"state"//state

#endif // DEBUG