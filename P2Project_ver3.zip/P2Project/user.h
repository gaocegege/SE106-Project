#include "information.h"
#include "message.h"
#include <list>

using namespace std;

struct User
{
	Information userInfo;
	list<Message> messageList;
	long pointerToData;
	int ID;
};