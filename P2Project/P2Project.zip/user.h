#include "information.h"
#include "message.h"
#include <list>

using namespace std;

struct User
{
	Information userInfo;
	long pointerToData;
};