#ifndef BASE_H
#define BASE_H

#define LENGTHOFMESSAGE 140
#define LENGTHOFID		20
#define LENGTHOFPWD		32 //the length of the pwd is 8-32
#define LENGTHOFNAME	20
#define LENGTHOFBIR		10 //XXXX-XX-XX

#define INFOFILE "info"
#define INDEXFILE "index"
#define MESSAGEFILE "meg"
#define LIKEFILE "like"

#endif // DEBUG