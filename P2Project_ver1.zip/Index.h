#include <string>
#include "base.h"
using namespace std;

struct RecordNode
{
	char username[LENGTHOFID];
	int pointer;
	bool operator==(const RecordNode& x)
	{
		return  this->username == x.username;
	}
};