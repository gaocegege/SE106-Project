#include "hash.h"

bool isPrime(int x)
{
	for (int i = 2; i * i <= x; ++i)
	{
		if (x % i == 0)
			return false;
	}
	return true;
}

int nextprime(int x)
{
	for (;; ++x)
	{
		if (isPrime(x))
			return x;
	}
}

void HashTable::rehash()
{
	vector<list<RecordNode>> oldLists = theLists;
	theLists.resize(nextprime(2 * theLists.size()));
	for (size_t j = 0; j < theLists.size(); ++j)
		theLists[j].clear();
	currentSize = 0;
	for (size_t i = 0; i < oldLists.size(); ++i)
	{
		list<RecordNode>::iterator itr = oldLists[i].begin();
		while (itr != oldLists[i].end())
			insert(*itr++);
	}
}

int HashTable::myhash(RecordNode &x)//BKDRHash
{
	unsigned  int  seed = 131;  //  31 131 1313 13131 131313 etc..
	unsigned  int  hash = 0;
	for (int i = 0; i < LENGTHOFID; i++)
	{
		if (x.username[i] == '\0')
			break;
		hash = hash  *  seed + x.username[i];
	}
	return  (hash & 0x7FFFFFFF) % (H + 1);
}

int HashTable::myhash(char *x)
{
	unsigned  int  seed = 131;  //  31 131 1313 13131 131313 etc..
	unsigned  int  hash = 0;
	for (int i = 0; i < LENGTHOFID; i++)
	{
		if (x[i] == '\0')
			break;
		hash = hash  *  seed + x[i];
	}
	return  (hash & 0x7FFFFFFF) % (H + 1);
}

HashTable::HashTable(int size)
{
	theLists.resize(size);
}

RecordNode *HashTable::contains(char *x)
{
	int h = myhash(x);
	RecordNode *buf;
	list<RecordNode> &whichList = this->theLists[h];
	list<RecordNode>::iterator itr = whichList.begin();
	while (itr != whichList.end())
	{
		if (strcmp((*itr).username, x) == 0)
		{
			buf = &(*itr);
			return buf;
		}
	}
	return NULL;
}

void HashTable::makeEmpty()
{
	for (size_t i = 0; i < theLists.size(); ++i)
		theLists[i].clear();
}

bool HashTable::insert(RecordNode &x)
{
	int h = myhash(x);
	list<RecordNode> &whichList = theLists[h];
	if (find(whichList.begin(), whichList.end(), x) != whichList.end())
		return false;
	whichList.push_back(x);
	if (++currentSize > theLists.size())
		rehash();
	return true;
}

bool HashTable::remove(RecordNode &x)//maybe wrong
{
	list<RecordNode> &whichList = theLists[myhash(x)];
	list<RecordNode>::iterator itr = find(whichList.begin(), whichList.end(), x);
	if (itr == whichList.end())
		return false;
	whichList.erase(itr);
	--currentSize;
	return true;
}

void HashTable::load()//����һ������һ�������Ĵ洢��ȡ�����Գ���
{
	ifstream fin(INDEXFILE, ios::in | ios::binary);
	RecordNode buf;
	while (fin.peek() != EOF)
	{
		fin.read((char *)(&buf.username), sizeof(char)*LENGTHOFID);
		fin.read((char *)(&buf.pointer), sizeof(int));
		this->insert(buf);
	}
	fin.close();
	return;
}

void HashTable::dump()//bug
{
	ofstream fout(INDEXFILE, ios::out | ios::binary);
	for (int i = 0; i < theLists.size(); i++)
	{
		if (theLists[i].size() == 0)
			continue;
		list<RecordNode>::iterator itr = theLists[i].begin();
		while (itr != theLists[i].end())
		{
			fout.write((char *)&(*itr), sizeof(RecordNode));
			itr++;
		}
	}
}