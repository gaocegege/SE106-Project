#ifndef INFORMATION_H
#define INFORMATION_H

#include <stdlib.h>
#include <string>

struct Information
{
	char identification[LENGTHOFID];
	char password[LENGTHOFPWD];
	char name[LENGTHOFNAME];
	bool gender;
	char birthday[LENGTHOFBIR];
	long pointer;
};

typedef Information *Userinfo;

#endif