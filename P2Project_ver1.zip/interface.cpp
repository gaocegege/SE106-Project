#include "interface.h"
#include <iostream>
#include "information.h"
#include "message.h"

using namespace std;

Interface::Interface()
:cmd_off(""), quitFlag(false), cmd_on("")
{
	relationship = new OLGraph();
	hash = new HashTable();
	argc_m.clear();
}

void Interface::getInput_offline()//get the command
{
	cin >> cmd_off;
	commandExec_offline();
}

void Interface::getInput_online()
{
	cin >> cmd_on;
	commandExec_online();
}

void Interface::usage_offline()//output the usage_offline
{
	cout << "usage_offline:\n"//print all the command that the user can input
		<< "-h\tHelp\n"
		<< "-l\tLog in\n"
		<< "-q\tQuit\n"
		<< "-r\tregister\n"
		/*add more cmd_off supported*/
		<< "\n";
}

void Interface::usage_online()
{
	cout << "usage_online:\n"
		<< "-h\tHelp\n"
		<< "-q\tQuit\n"
		<< "-p\tPush a message\n"
		<< "-s\tShow the messages\n"
		<< "-a\tShow all the messages that the people you like push\n"
		/*add more cmd_on supported*/
		<< "\n";
}

void Interface::commandExec_offline()//execute the command
{
	if (cmd_off == "-h")
		usage_offline();
	else if (cmd_off == "-q")
	{
		quitFlag = true;
		cout << "Bye Bye!\n";
	}
	else if (cmd_off == "-l")
	{
		login();
	}
	else if (cmd_off == "-r")
	{
		register_m();
	}
	else if (cmd_off == "-update")
	{
		updateInfo();
	}
	else if (cmd_off == "-test")
	{
		test();
	}
	else
	{
		cout << "The command is not valid.\n\n";
		usage_offline();
		cout << "\n";
	}
}

void Interface::commandExec_online()
{
	if (cmd_on == "-h")
	{
		usage_online();
	}
	else if (cmd_on == "-q")
	{
		logFlag = false;
	}
	else if (cmd_on == "-p")
	{
		pushMessage();
	}
	else if (cmd_on == "-s")
	{
		showMessages();
	}
	/*add more cmd*/
	else
		cout << "Online error\n";
}

void Interface::display_offline()//output something
{
	cout << "Welcome to the system. I'm Cece, and I will be your guide in the system.\n"
		<< "Hope you happy:D\n"
		<< "The system allows you to read what your friends push to the system, and you can push,too.\n"
		<< "Let's begin to play!\n\n";
}

void Interface::display_online()
{
	cout << "Login successfully!\n"
		<< "Now you can deal with your information and messages and so on\n";
}

void Interface::register_m()
{
	Information newuser;
	string test;
	RecordNode buf;
	cout << "please input the new username:(1-20 chars)\n";
	cin >> newuser.identification;
	
	//check whether the name is in the list, if not, then
	if (hash->contains(newuser.identification) != NULL)
	{
		cout << "The username has been used\n";
		return;
	}

	cout << "The username is still available.please input the password:\n";
	cin >> newuser.password;
	//if the pwd meet the need, then
	cout << "please input the password again:\n";
	cin >> test;
	if (newuser.password != test)//should have a loop to determine
	{
		cout << "The password is wrong, the login is failed\n";
		return;
	}
	newuser.pointer = 1;
	cout << "Name\n";
	cin >> newuser.name;
	cout << "Gender:(1 == man, 0 == woman)\n";
	cin >> newuser.gender;
	cout << "Birthday:(XXXX-XX-XX)\n";
	cin >> newuser.birthday;

	ofstream ofs(INFOFILE, ios_base::in | ios_base::out | ios::binary);
	ofs.seekp(0, ios::end);
	buf.pointer = ofs.tellp();//buf = -1~?
	if (buf.pointer == -1)
		buf.pointer = 0;
	ofs.close();
	ofs.open(INFOFILE, ios::out | ios::binary | ios::app);
	ofs.write((char *)(&newuser), sizeof(Information));
	strcpy_s(buf.username, newuser.identification);
	cout << sizeof(Information);

	hash->insert(buf);
	relationship->addVex(buf.username);

	cout << "Congratulation!\n\n";
}

void Interface::login()
{
	Information buf;
	Information ref;
	cout << "Input the username, please.\n";
	cin >> buf.identification;

	cout << "Please input the password.\n";
	cin >> buf.password;

	RecordNode *r_buf = hash->contains(buf.identification);
	if (r_buf == NULL)
	{
		cout << "The username is wrong!\n";
		return;
	}

	ifstream ifs(INFOFILE, ios::in | ios::binary);
	ifs.seekg(r_buf->pointer);
	ifs.read((char *)(&ref), sizeof(Information));
	user.userInfo = ref;//maybe wrong//no = operator~?
	user.pointerToData = r_buf->pointer;
	//TO DO
	if (strcmp(ref.password, buf.password) == 0)
	{
		cout << "Successful!\n";
		logFlag = true;
	}
}

void Interface::load()
{
	hash->load();
}

void Interface::updateInfo()
{
	ifstream fin(INFOFILE, ios::in | ios::binary);
	ofstream fout(INDEXFILE, ios::out | ios::binary);
	int number = 0;
	while (fin.peek() != EOF)
	{
		Information buf;
		RecordNode m_buf;
		fin.read((char *)&buf, sizeof(Information));
		cout << buf.identification << "\tEnd\n";
		strcpy_s(m_buf.username, buf.identification);
		m_buf.pointer = number * sizeof(Information);
		fout.write((char *)&m_buf, sizeof(RecordNode));
	}
	fin.close();
	fout.close();
}

void Interface::quitDo_offline()
{
	//memory to disk
	hash->dump();
}

void Interface::onlineWork()
{
	prepareToLogin();
	display_online();
	usage_online();
	while (1)
	{
		if (logFlag == false)
			break;
		getInput_online();
	}
	quitDo_online();
}

void Interface::prepareToLogin()
{
	Message meg;
	ifstream ifs(MESSAGEFILE, ios::in | ios::binary);
	if (user.userInfo.pointer != 1)
	{
		ifs.seekg(user.userInfo.pointer);//�ҵ���һ����Ϣ��λ��
		ifs.read((char *)&meg, sizeof(Message));
		user.messageList.push_back(meg);
		while (1)
		{
			if (meg.isFinished == true)
			{
				break;
			}
			ifs.seekg(meg.pointer);
			ifs.read((char *)&meg, sizeof(Message));
			user.messageList.push_back(meg);
		}
	}
}

void Interface::quitDo_online()
{
	if (user.messageList.empty())//empty
		return;
	list<Message>::iterator itr = user.messageList.begin();
	if ((*itr).isFinished == 1)
	{
		if ((*itr).pointer == 1)
		{
			ofstream ofs1(INFOFILE, ios_base::in | ios_base::out | ios::binary);
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			(*itr).pointer = 2;
			ofs1.seekp(user.pointerToData);
			ofs.seekp(0, ios::end);
			user.userInfo.pointer = ofs.tellp();
			if (user.userInfo.pointer == -1)
				user.userInfo.pointer = 0;//may have a bug
			ofs.close();

			ofs.open(MESSAGEFILE, ios::out | ios::binary | ios::app);
			ofs1.write((char *)(&user.userInfo), sizeof(Information));//maybe wrong//can be covered~?
			ofs.write((char *)&(*itr), sizeof(Message));
			itr++;
			ofs.close();
			ofs1.close();
		}
		else
			itr++;
	}
	else
	{
		if ((*itr).pointer == 1)
		{
			ofstream ofs1(INFOFILE, ios_base::in | ios_base::out | ios::binary);
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofs.seekp(0, ios::end);
			(*itr).pointer = ofs.tellp();
			if ((*itr).pointer == -1)
			{
				((*itr).pointer) = 0;//may have a bug
			}
			ofs.close();

			ofs.open(MESSAGEFILE, ios::out | ios::binary | ios::app);
			ofs1.seekp(user.pointerToData);
			user.userInfo.pointer = (*itr).pointer;
			ofs1.write((char *)&user.userInfo, sizeof(Information));//maybe wrong//can be covered~?
			(*itr).pointer += sizeof(Message);
			ofs.write((char *)&(*itr), sizeof(Message));
			ofs.close();
			ofs1.close();
		}
		else if ((*itr).pointer == 2)//err:the pointer is 0
		{
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofs.seekp(0, ios::end);
			(*itr).pointer = ofs.tellp();//bug//ofs.tellp == 0//why//solved
			if ((*itr).pointer == -1)
				(*itr).pointer = 0;
			ofs.close();

			ofstream ofs1(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofs1.seekp(user.userInfo.pointer);
			ofs1.write((char *)&(*itr), sizeof(Message));
			ofs1.close();
		}
		itr++;
	}

	while (itr != user.messageList.end())
	{//���԰�forѭ���Ķ���ȡ��ȥ��Ȼ���if (itr == user.messageList.begin())�ó�ȥ����������ѭ�����ж�if
		if ((*itr).isFinished == 1)
		{
			if ((*itr).pointer == 1)
			{
				ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary | ios::app);
				(*itr).pointer = 2;
				ofs.write((char *)&(*itr), sizeof(Message));
				break;//maybe wrong
			}
			else
				break;
		}
		else if ((*itr).pointer == 1)
		{
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofs.seekp(0, ios::end);
			(*itr).pointer = ofs.tellp();
			if ((*itr).pointer == -1)
			{
				((*itr).pointer) = 0;//may have a bug
			}
			ofs.close();

			ofs.open(MESSAGEFILE, ios::out | ios::binary | ios::app);
			(*itr).pointer += sizeof(Message);
			ofs.write((char *)&(*itr), sizeof(Message));
			itr++;
		}
		else if ((*itr).pointer == 2)
		{
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofstream ofs2(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			//get the (*itr) position
			itr--;
			ofs2.seekp((*itr).pointer);
			itr++;

			ofs.seekp(0, ios::end);
			(*itr).pointer = ofs.tellp();
			if ((*itr).pointer == -1)
			{
				((*itr).pointer) = 0;//may have a bug
			}
			ofs.close();

			ofs2.write((char *)&(*itr), sizeof(Message));
		}
		else
			itr++;
	}
	//clear all the info
	user.messageList.clear();
}

void Interface::pushMessage()
{
	Message meg_buf;
	cout << "Now you can push a message no more than 140 chars\n";
	cin >> meg_buf.message;
	//only the last element is finished block
	if (user.messageList.size() >= 1)
	{
		user.messageList.back().isFinished = false;
	}

	meg_buf.pointer = 1;
	meg_buf.isFinished = 1;
	user.messageList.push_back(meg_buf);
}

void Interface::showAllMessages()
{
	int index = relationship->LocateVex(this->user.userInfo.identification);
	OLGArc *buf = relationship->xlist[index].firstout;
	while (buf != NULL)
	{
		cout << relationship->xlist[buf->tailvex].username << endl;
	}
}

void Interface::showMessages()
{
	cout << "The Messages:\n";
	list<Message>::iterator itr = user.messageList.begin();
	int number = 0;
	for (; itr != user.messageList.end(); itr++, number++)
	{
		cout << number << ".\t" << (*itr).message << endl;
	}
}

void Interface::changeInfo()
{

}

void Interface::searchSomeone()
{

}

void Interface::likeSomeone()
{
	char buf[LENGTHOFID];
	cout << "Please input the username\n";
	cin >> buf;
	if (hash->contains(buf) == NULL)
	{
		cout << "The username do not exist\n";
		return;
	}
	relationship->InsertArc(this->user.userInfo.identification, buf);
}

void Interface::shareMessage()
{

}

void Interface::work()
{
	while (1)
	{
		if (logFlag == true)
		{
			onlineWork();
		}
		cout << "Then what you want to do~?\n";
		if (quitFlag == true)
			break;
		getInput_offline();
	}
}

void Interface::test()
{
	ofstream ofs("hehe");
	ofs << "hehe";
	ofs.close();
}

void Interface::clear()
{
	
}

void Interface::beginTowork()//make the interface work
{
	load();
	display_offline();
	usage_offline();
	getInput_offline();
	work();
	quitDo_offline();
}