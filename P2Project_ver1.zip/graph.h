#ifndef GRAPH_H
#define GRAPH_H

#include "base.h"

typedef struct OLGArc
{
	int tailvex;
	int headvex;
	struct OLGArc *hlink;
	struct OLGArc *tlink;
}OLGArc;

typedef struct VexNode
{
	char username[LENGTHOFID];
	OLGArc *firstin;
	OLGArc *firstout;
}OLGVNode;

#define MAX_VERTEX_NUM 100

class OLGraph
{
private:
	OLGVNode xlist[MAX_VERTEX_NUM];
	int vexnum;
	int arcnum;
public:
	friend class Interface;
	OLGraph();
	void dump();
	int LocateVex(char *x);
	void addVex(char *x);
	void DeleteVex(char *v);
	void InsertArc(char *u, char *v);
	void DeleteArc(char *u, char *v);
};

#endif