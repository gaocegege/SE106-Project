#ifndef INFORMATION_H
#define INFORMATION_H

#include <stdlib.h>
#include <string>

struct Information
{
	char identification[LENGTHOFID];
	char password[LENGTHOFPWD];
	char name[LENGTHOFNAME];
	char teleNumber[LENGTHOFTELEPHONE];
	bool gender;
	char birthday[LENGTHOFBIR];
	long pointer;
	int indexNumber;
};

typedef Information *Userinfo;

#endif