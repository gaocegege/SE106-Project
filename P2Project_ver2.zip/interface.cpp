#include "interface.h"
#include <iostream>
#include "information.h"
#include "message.h"

using namespace std;

Interface::Interface()
:cmd_off(""), quitFlag(false), cmd_on("")
{
	int buf = 0;
	ifstream ifs(STATEFILE, ios::in | ios::binary);
	if (ifs.peek() == EOF)
	{
		ofstream ofs(STATEFILE, ios::out | ios::binary);
		ofs.write((char *)&buf, sizeof(buf));
		ofs.close();
	}
	ifs.close();
	relationship = new OLGraph();
	hash = new HashTable();
	argc_m.clear();
}

void Interface::getInput_offline()//get the command
{
	cin >> cmd_off;
	commandExec_offline();
}

void Interface::getInput_online()
{
	cin >> cmd_on;
	commandExec_online();
}

void Interface::usage_offline()//output the usage_offline
{
	cout << "usage_offline:\n"//print all the command that the user can input
		<< "-h\tHelp\n"
		<< "-l\tLog in\n"
		<< "-q\tQuit\n"
		<< "-r\tregister\n"
		/*add more cmd_off supported*/
		<< "\n";
}

void Interface::usage_online()
{
	cout << "usage_online:\n"
		<< "-h\tHelp\n"
		<< "-q\tQuit\n"
		<< "-p\tPush a message\n"
		<< "-s\tShow the messages\n"
		<< "-a\tShow all the messages that the people you like push\n"
		<< "-l\tLike someone\n"
		<< "-c\tChange the user info\n"
		<< "-w\twatch who like you\n"
		/*add more cmd_on supported*/
		<< "\n";
}

void Interface::commandExec_offline()//execute the command
{
	if (cmd_off == "-h")
		usage_offline();
	else if (cmd_off == "-q")
	{
		quitFlag = true;
		cout << "Bye Bye!\n";
	}
	else if (cmd_off == "-l")
	{
		login();
	}
	else if (cmd_off == "-r")
	{
		register_m();
	}
	else if (cmd_off == "-update")
	{
		updateInfo();
	}
	else if (cmd_off == "-test")
	{
		test();
	}
	else
	{
		cout << "The command is not valid.\n\n";
		usage_offline();
		cout << "\n";
	}
}

void Interface::commandExec_online()
{
	if (cmd_on == "-h")
	{
		usage_online();
	}
	else if (cmd_on == "-q")
	{
		logFlag = false;
	}
	else if (cmd_on == "-p")
	{
		pushMessage();
	}
	else if (cmd_on == "-s")
	{
		showMessages();
	}
	else if (cmd_on == "-a")
	{
		showAllMessages();
	}
	else if (cmd_on == "-l")
	{
		likeSomeone();
	}
	else if (cmd_on == "-c")
	{
		changeInfo();
	}
	else if (cmd_on == "-w")
	{
		peopleWhoLikeMe();
	}
	/*add more cmd*/
	else
		cout << "command error\n";
}

void Interface::display_offline()//output something
{
	cout << "Welcome to the system. I'm Cece, and I will be your guide in the system.\n"
		<< "Hope you happy:D\n"
		<< "The system allows you to read what your friends push to the system, and you can push,too.\n"
		<< "Let's begin to play!\n\n";
}

void Interface::display_online()
{
	cout << "Login successfully!\n"
		<< "Now you can deal with your information and messages and so on\n";
}

void Interface::register_m()
{
	Information newuser;
	string test;
	RecordNode buf;
	int number;
	cout << "please input the new username:(1-20 chars)\n";
	cin >> newuser.identification;
	
	//check whether the name is in the list, if not, then
	if (hash->contains(newuser.identification).pointer != -2)
	{
		cout << "The username has been used\n";
		return;
	}

	cout << "The username is still available.please input the password:\n";
	cin >> newuser.password;
	//if the pwd meet the need, then
	cout << "please input the password again:\n";
	cin >> test;
	if (newuser.password != test)//should have a loop to determine
	{
		cout << "The password is wrong, the login is failed\n";
		return;
	}
	newuser.pointer = 1;
	cout << "Name\n";
	cin >> newuser.name;
	cout << "Gender:(1 == man, 0 == woman)\n";
	cin >> newuser.gender;
	cout << "Birthday:(XXXX-XX-XX)\n";
	cin >> newuser.birthday;

	ifstream ifs(STATEFILE, ios::in | ios::binary);
	ifs.read((char *)&number, sizeof(number));
	ifs.close();

	ofstream ofs1(STATEFILE, ios::out | ios::binary);
	ofstream ofs(INFOFILE, ios_base::in | ios_base::out | ios::binary);

	//get the pointer
	ofs.seekp(0, ios::end);
	buf.pointer = ofs.tellp();//buf = -1~?
	if (buf.pointer == -1)
		buf.pointer = 0;
	ofs.close();

	//save the data
	ofs.open(INFOFILE, ios::out | ios::binary | ios::app);
	strcpy_s(buf.username, newuser.identification);
	newuser.indexNumber = number;
	number++;
	hash->insert(buf);
	relationship->addVex(buf.username);
	ofs1.write((char *)&number, sizeof(number));
	ofs.write((char *)(&newuser), sizeof(Information));

	cout << "Congratulation!\n\n";
}

void Interface::login()
{
	Information buf;
	Information ref;
	cout << "Input the username, please.\n";
	cin >> buf.identification;

	cout << "Please input the password.\n";
	cin >> buf.password;

	RecordNode r_buf = hash->contains(buf.identification);
	if (r_buf.pointer == -2)
	{
		cout << "The username is wrong!\n";
		return;
	}

	ifstream ifs(INFOFILE, ios::in | ios::binary);
	ifs.seekg(r_buf.pointer);
	ifs.read((char *)(&ref), sizeof(Information));
	user.userInfo = ref;//maybe wrong//no = operator~?
	user.pointerToData = r_buf.pointer;
	//TO DO
	if (strcmp(ref.password, buf.password) == 0)
	{
		cout << "Successful!\n";
		logFlag = true;
	}
}

void Interface::load()
{
	hash->begin();
	relationship->load();
}

//wrong
void Interface::updateInfo()
{
	ifstream fin(INFOFILE, ios::in | ios::binary);
	ofstream fout(INDEXFILE, ios::out | ios::binary);
	int number = 0;
	while (fin.peek() != EOF)
	{
		Information buf;
		RecordNode m_buf;
		fin.read((char *)&buf, sizeof(Information));
		cout << buf.identification << "\tEnd\n";
		strcpy_s(m_buf.username, buf.identification);
		m_buf.pointer = number * sizeof(Information);
		fout.write((char *)&m_buf, sizeof(RecordNode));
	}
	fin.close();
	fout.close();
}

void Interface::quitDo_offline()
{
	//memory to disk
	relationship->dump();
}

void Interface::onlineWork()
{
	prepareToLogin();
	display_online();
	usage_online();
	while (1)
	{
		if (logFlag == false)
			break;
		getInput_online();
	}
	quitDo_online();
}

void Interface::prepareToLogin()
{
	Message meg;
	ifstream ifs(MESSAGEFILE, ios::in | ios::binary);
	if (user.userInfo.pointer != 1)
	{
		ifs.seekg(user.userInfo.pointer);//�ҵ���һ����Ϣ��λ��
		ifs.read((char *)&meg, sizeof(Message));
		user.messageList.push_back(meg);
		while (1)
		{
			if (meg.isFinished == true)
			{
				break;
			}
			ifs.seekg(meg.pointer);
			ifs.read((char *)&meg, sizeof(Message));
			user.messageList.push_back(meg);
		}
	}
}

void Interface::quitDo_online()
{
	if (user.messageList.empty())//empty
		return;
	list<Message>::iterator itr = user.messageList.begin();
	if ((*itr).isFinished == 1)
	{
		if ((*itr).pointer == 1)
		{
			ofstream ofs1(INFOFILE, ios_base::in | ios_base::out | ios::binary);
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			(*itr).pointer = 2;
			ofs1.seekp(user.pointerToData);
			ofs.seekp(0, ios::end);
			user.userInfo.pointer = ofs.tellp();
			if (user.userInfo.pointer == -1)
				user.userInfo.pointer = 0;//may have a bug
			ofs.close();

			ofs.open(MESSAGEFILE, ios::out | ios::binary | ios::app);
			ofs1.write((char *)(&user.userInfo), sizeof(Information));//maybe wrong//can be covered~?
			ofs.write((char *)&(*itr), sizeof(Message));
			itr++;
			ofs.close();
			ofs1.close();
		}
		else
			itr++;
	}
	else
	{
		if ((*itr).pointer == 1)
		{
			ofstream ofs1(INFOFILE, ios_base::in | ios_base::out | ios::binary);
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofs.seekp(0, ios::end);
			(*itr).pointer = ofs.tellp();
			if ((*itr).pointer == -1)
			{
				((*itr).pointer) = 0;//may have a bug
			}
			ofs.close();

			ofs.open(MESSAGEFILE, ios::out | ios::binary | ios::app);
			ofs1.seekp(user.pointerToData);
			user.userInfo.pointer = (*itr).pointer;
			ofs1.write((char *)&user.userInfo, sizeof(Information));//maybe wrong//can be covered~?
			(*itr).pointer += sizeof(Message);
			ofs.write((char *)&(*itr), sizeof(Message));
			ofs.close();
			ofs1.close();
		}
		else if ((*itr).pointer == 2)//err:the pointer is 0
		{
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofs.seekp(0, ios::end);
			(*itr).pointer = ofs.tellp();//bug//ofs.tellp == 0//why//solved
			if ((*itr).pointer == -1)
				(*itr).pointer = 0;
			ofs.close();

			ofstream ofs1(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofs1.seekp(user.userInfo.pointer);
			ofs1.write((char *)&(*itr), sizeof(Message));
			ofs1.close();
		}
		itr++;
	}

	while (itr != user.messageList.end())
	{//���԰�forѭ���Ķ���ȡ��ȥ��Ȼ���if (itr == user.messageList.begin())�ó�ȥ����������ѭ�����ж�if
		if ((*itr).isFinished == 1)
		{
			if ((*itr).pointer == 1)
			{
				ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary | ios::app);
				(*itr).pointer = 2;
				ofs.write((char *)&(*itr), sizeof(Message));
				break;//maybe wrong
			}
			else
				break;
		}
		else if ((*itr).pointer == 1)
		{
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofs.seekp(0, ios::end);
			(*itr).pointer = ofs.tellp();
			if ((*itr).pointer == -1)
			{
				((*itr).pointer) = 0;//may have a bug
			}
			ofs.close();

			ofs.open(MESSAGEFILE, ios::out | ios::binary | ios::app);
			(*itr).pointer += sizeof(Message);
			ofs.write((char *)&(*itr), sizeof(Message));
			itr++;
		}
		else if ((*itr).pointer == 2)
		{
			ofstream ofs(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			ofstream ofs2(MESSAGEFILE, ios_base::in | ios_base::out | ios::binary);
			//get the (*itr) position
			itr--;
			ofs2.seekp((*itr).pointer);
			itr++;

			ofs.seekp(0, ios::end);
			(*itr).pointer = ofs.tellp();
			if ((*itr).pointer == -1)
			{
				((*itr).pointer) = 0;//may have a bug
			}
			ofs.close();

			ofs2.write((char *)&(*itr), sizeof(Message));
		}
		else
			itr++;
	}
	//clear all the info
	user.messageList.clear();
}

void Interface::pushMessage()
{
	Message meg_buf;
	cout << "Now you can push a message no more than 140 chars\n";
	cin >> meg_buf.message;
	//only the last element is finished block
	if (user.messageList.size() >= 1)
	{
		user.messageList.back().isFinished = false;
	}

	meg_buf.pointer = 1;
	meg_buf.isFinished = 1;
	user.messageList.push_back(meg_buf);
}

void Interface::showAllMessages()
{
	//To Do
	int index = user.userInfo.indexNumber;
	OLGArc *buf = relationship->xlist[index].firstout;
	while (buf != NULL)
	{
		cout << relationship->xlist[buf->headvex].username << endl;
		buf = buf->tlink;
	}
}

void Interface::showMessages()
{
	cout << "The Messages:\n";
	list<Message>::iterator itr = user.messageList.begin();
	int number = 0;
	for (; itr != user.messageList.end(); itr++, number++)
	{
		cout << number << ".\t" << (*itr).message << endl;
	}
}

void Interface::changeInfo()
{
	char cmd_change;
	ofstream ofs(INFOFILE, ios_base::in | ios_base::out | ios::binary);

	cout << "You can change:\n"
		<< "1.password\n"
		<< "2.Name\n"
		<< "3.Birthday\n"
		<< "4.Telephone number\n"
		<<"Please input the number\n";
	cin >> cmd_change;

	switch (cmd_change)
	{
	case '1':
		char newPwd[LENGTHOFPWD];
		cout << "Please input the new password\n";
		cin >> newPwd;
		cout << "Your new password is " << newPwd << endl;
		strcpy_s(user.userInfo.password, newPwd);
		ofs.seekp(this->user.pointerToData);
		ofs.write((char *)(&user.userInfo), sizeof(user.userInfo));
		break;
	case '2':
		char newName[LENGTHOFNAME];
		cout << "Please input the name you want to change\n";
		cin >> newName;
		cout << "Your name is " << newName << endl;
		strcpy_s(user.userInfo.name, newName);
		ofs.seekp(this->user.pointerToData);
		ofs.write((char *)(&user.userInfo), sizeof(user.userInfo));
		break;
	case '3':
		char newBir[LENGTHOFBIR];
		cout << "Please input the birthday you want to change\n";
		cin >> newBir;
		cout << "Your birthday is " << newBir << endl;
		strcpy_s(user.userInfo.birthday, newBir);
		ofs.seekp(this->user.pointerToData);
		ofs.write((char *)(&user.userInfo), sizeof(user.userInfo));
		break;
	case '4':
		char newTele[LENGTHOFTELEPHONE];
		cout << "Please input your new tele number\n";
		cin >> newTele;
		cout << "Your new tele number is " << newTele << endl;
		strcpy_s(user.userInfo.teleNumber, newTele);
		ofs.seekp(this->user.pointerToData);
		ofs.write((char *)(&user.userInfo), sizeof(user.userInfo));
	default:
		cout << "The command you input is wrong\n";
		break;
	}
}

void Interface::searchSomeone()
{

}

void Interface::peopleWhoLikeMe()
{
	int number = 0;
	int index = user.userInfo.indexNumber;
	OLGArc *buf = relationship->xlist[index].firstin;
	while (buf != NULL)
	{
		cout << number << ".\t" << relationship->xlist[buf->tailvex].username << endl;
		buf = buf->hlink;
		number++;
	}
}

void Interface::likeSomeone()
{
	char buf[LENGTHOFID];
	RecordNode r_buf;
	cout << "Please input the username\n";
	cin >> buf;
	if (strcmp(buf, user.userInfo.identification) == 0)
	{
		cout << "You can't like yourself\n";
		return;
	}
	r_buf = hash->contains(buf);
	if (r_buf.pointer == -2)
	{
		cout << "The username do not exist\n";
		return;
	}
	relationship->InsertArc(this->user.userInfo.identification, buf);
}

void Interface::shareMessage()
{

}

void Interface::work()
{
	while (1)
	{
		if (logFlag == true)
		{
			onlineWork();
		}
		cout << "Then what you want to do~?\n";
		if (quitFlag == true)
			break;
		getInput_offline();
	}
}

void Interface::test()
{
	
}

void Interface::clear()
{
	
}

void Interface::beginTowork()//make the interface work
{
	load();
	display_offline();
	usage_offline();
	getInput_offline();
	work();
	quitDo_offline();
}