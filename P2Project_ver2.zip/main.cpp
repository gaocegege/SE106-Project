#include "interface.h"
#include <iostream>
using namespace std;

int main()
{
	Interface *ui = new Interface();
	ui->beginTowork();
	system("pause");
	return 0;
}
