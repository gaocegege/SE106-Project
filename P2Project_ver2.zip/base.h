#ifndef BASE_H
#define BASE_H

#define LENGTHOFMESSAGE		140
#define LENGTHOFID			20
#define LENGTHOFPWD			32 //the length of the pwd is 8-32
#define LENGTHOFNAME		20
#define LENGTHOFBIR			10 //XXXX-XX-XX
#define LENGTHOFTELEPHONE	11

#define INFOFILE	"info"//userInfo
#define INDEXFILE	"index"//index file
#define MESSAGEFILE "meg"//message
#define LIKEFILE	"like"//relationship
#define STATEFILE	"state"//state

#endif // DEBUG