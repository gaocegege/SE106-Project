#ifndef GRAPH_H
#define GRAPH_H

#include "base.h"

typedef struct OLGArc
{
	long tailvex;
	long headvex;
	long hlink;
	long tlink;
}OLGArc;

typedef struct VexNode
{
	char username[LENGTHOFID];
	long firstin;
	long firstout;
}OLGVNode;

#define MAX_VERTEX_NUM 100000

class OLGraph
{
private:
	long pointer;
	void DeleteArc(long po1, long pointer);
public:
	friend class Interface;
	OLGraph();
	void load();
	void dump();
	long addVex(char *x);
	bool contains(long pointer);
	void DeleteVex();
	void InsertArc(long pointer);
	void DeleteArc(long pointer);
	void setPo(long pointer);
};

#endif