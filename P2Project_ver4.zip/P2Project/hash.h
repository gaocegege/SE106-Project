#ifndef HASH_H
#define HASH_H

#include "Index.h"
#include "base.h"
#include <vector>
#include <fstream>
#include <list>

#define H 101

using namespace std;

class HashTable
{
public:
	HashTable(int size = H);
	RecordNode contains(char *x);
	void makeEmpty();
	bool insert(RecordNode &x);
	void begin();
	void dump();
private:
	int myhash(RecordNode &x);
	int myhash(char *x);
	int currentSize;
};

#endif