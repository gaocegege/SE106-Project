﻿#include "graph.h"
#include <string>
#include <fstream>

using namespace std;

OLGraph::OLGraph()//rewrite version
:vexnum(0), arcnum(0)
{
}

void OLGraph::load()
{
	ifstream ifs(LIKEFILE, ios::in | ios::binary);
	if (ifs.peek() == EOF)
		return;
	ifs.read((char *)&vexnum, sizeof(vexnum));
	ifs.read((char *)&arcnum, sizeof(arcnum));
	if (ifs.peek() == EOF)
		return;
	for (int i = 0; i < vexnum; i++)
	{
		ifs.read((char *)&(xlist[i].username), sizeof(xlist[i].username));
		xlist[i].firstin = NULL;
		xlist[i].firstout = NULL;
	}
	for (int i = 0; i < vexnum; i++)
	{
		int head = 0;
		int tail = 0;
		ifs.read((char *)&tail, sizeof(tail));
		while (1)
		{
			ifs.read((char *)&head, sizeof(head));
			if (head != -1)
			{
				OLGArc *buf = (OLGArc *)malloc(sizeof(OLGArc));
				buf->tailvex = tail;
				buf->headvex = head;
				//maybe wrong
				buf->hlink = xlist[buf->headvex].firstin;
				buf->tlink = xlist[buf->tailvex].firstout;
				xlist[tail].firstout = buf;
				xlist[head].firstin = buf;
			}
			else if (head == -1)
				break;
		}
	}
}

void OLGraph::dump()
{
	int endFlag = -1;
	ofstream ofs(LIKEFILE, ios::out | ios::binary);
	ofs.write((char *)&vexnum, sizeof(vexnum));
	ofs.write((char *)&arcnum, sizeof(arcnum));
	for (int i = 0; i < vexnum; i++)
	{
		ofs.write((char *)(&xlist[i].username), sizeof(xlist[i].username));
	}
	for (int i = 0; i < vexnum; i++)
	{
		ofs.write((char *)&i, sizeof(i));
		OLGArc *buf = xlist[i].firstout;
		while (buf != NULL)
		{
			ofs.write((char *)(&(buf->headvex)), sizeof(int));
			buf = buf->tlink;
		}
		ofs.write((char *)(&endFlag), sizeof(endFlag));
	}
}

int OLGraph::LocateVex(char *x)
{
	for (int i = 0; i<this->vexnum; ++i)
	if (strcmp(this->xlist[i].username, x) == 0)//maybe wrong
		return i;
	return -1;
}

void OLGraph::addVex(char *x)
{
	VexNode *buf = (VexNode *)malloc(sizeof(VexNode));
	strcpy_s(buf->username, x);
	buf->firstin = buf->firstout = NULL;
	xlist[vexnum] = *buf;
	vexnum++;
}

void OLGraph::InsertArc(char *u, char *v)//error//not sort as index
{
	int i, j;
	OLGArc *p;
	i = LocateVex(u);
	j = LocateVex(v);
	p = (OLGArc*)malloc(sizeof(OLGArc));
	p->headvex = j;
	p->tailvex = i;
	p->hlink = xlist[j].firstin;
	p->tlink = xlist[i].firstout;
	xlist[i].firstout = p;
	xlist[j].firstin = p;
	arcnum++;
}

void OLGraph::DeleteArc(char *u, char *v)
{
	int i, j;
	OLGArc *p, *q;
	i = LocateVex(u);
	j = LocateVex(v);
	//ÐÞ¸ÄuµÄ³ö»¡Á´±í
	if (xlist[i].firstout->headvex == j)
	{
		q = xlist[i].firstout;
		xlist[i].firstout = q->tlink;
		arcnum--;
	}
	else
	{
		for (p = xlist[i].firstout; p && (p->tlink != NULL) && (p->tlink->headvex != j); p = p->tlink);

		if (p && p->tlink)
		{
			q = p->tlink;
			p->tlink = q->tlink;
			arcnum--;
		}
	}
	//ÐÞ¸ÄvµÄÈë»¡Á´±í
	if (xlist[j].firstin->tailvex == i)
	{
		q = xlist[j].firstin;
		xlist[j].firstin = q->hlink;
		free(q);
	}
	else
	{
		for (p = xlist[j].firstin; p && (p->hlink) && (p->hlink->tailvex != i); p = p->hlink);
		if (p&&p->hlink)
		{
			q = p->hlink;
			p->hlink = q->hlink;
			free(q);
		}
	}
}

void OLGraph::DeleteVex(char *v)
{
	int k = LocateVex(v);
	OLGArc* p = NULL;
	OLGArc* q = NULL;
	for (int j = 0; j<vexnum; j++)   //±éÀúËùÓÐ½áµãµÄ³ö»¡Á´±í£¬ÕÒµ½´ýÉ¾µÄ»¡½áµã(ÒÔv×÷Îª»¡Í·½áµãµÄ»¡µÄ½áµã)£¬ÐÞ¸ÄÃ¿¸ö½áµãµÄÒªÐÞ¸Ä´¦µÄÖ¸Õë£¬±£³ÖÄ¿±ê½áµã±»É¾³ýºóÈÔ±£³ÖÔ­ÓÐµÄÁ¬Í¨ÐÔ
	{
		if (xlist[j].firstout == NULL)  //¸Ã¶¥µãÃ»ÓÐ³ö»¡Á´±í
			continue;
		else
		{
			if (xlist[j].firstout->headvex == k)    //³ö»¡Á´±íµÄµÚÒ»¸ö½áµãÇ¡ºÃÊÇÒªÉ¾³ýµÄ½áµã
			{
				q = xlist[j].firstout;
				xlist[j].firstout = q->tlink;
				arcnum--;
			}
			else
			{
				for (p = xlist[j].firstout; p && (p->tlink != NULL) && (p->tlink->headvex != k); p = p->tlink);

				if (p&&p->tlink)       //Ö®Ç°Ã»ÓÐ¼Óp->tlink!=NULL,Èôp->tlink==NULL£¬Ôòq==NULL,q->tlinkÒ²¾ÍÎÞÒâÒåÁË£¬Í¬ÉÏ²î²»¶à£¬»áÔì³É¸÷ÖÖÖ¸Õë´íÎó
				{
					q = p->tlink;
					p->tlink = q->tlink;
					arcnum--;
				}
			}
		}
	}
	//É¾³ývµÄ³ö»¡Á´±íºÍÈë»¡Á´±í
	p = xlist[k].firstout;
	while (p)
	{
		q = p;
		p = p->tlink;
		free(q);
	}
	p = xlist[k].firstin;
	while (p)
	{
		q = p;
		p = p->hlink;
		free(q);
	}
	//error
	//for (int j = k + 1; j<vexnum; j++)   //Êý×éÇ°ÒÆ
	//	xlist[j - 1] = xlist[j];
	//vexnum--;    //¶¥µãÊý¼õÒ»
	//for (int j = 0; j<vexnum; j++)
	//{
	//	for (p = xlist[j].firstout; p; p = p->tlink)
	//	{
	//		if (p->tailvex>k)
	//			p->tailvex--;
	//		if (p->headvex>k)
	//			p->headvex--;
	//	}
	//}
}